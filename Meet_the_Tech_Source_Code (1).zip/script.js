const projects = [
 {id:1,title:"SmartGrid Monitor",category:"Electrical",stage:"Prototype",creator:"Emeka Okafor",initials:"EO",role:"Electrical Engineer",description:"An intelligent energy monitoring concept designed to help facilities understand electricity usage and identify opportunities to improve efficiency.",icon:"ϟ",art:"",funding:"Seeking strategic partners",problem:"Energy users often have limited visibility into where and when electricity is being consumed.",solution:"A connected monitoring concept that presents energy-use information through a simple dashboard.",benefits:"Improved visibility, better energy planning and potential operating-cost savings."},
 {id:2,title:"SolarFlow Mini",category:"Renewable Energy",stage:"Testing",creator:"Amara James",initials:"AJ",role:"Renewable Energy Designer",description:"A compact solar power management concept focused on making small-scale renewable energy easier to monitor and manage.",icon:"☼",art:"art-energy",funding:"Open to investment enquiries",problem:"Small solar installations can be difficult for users to monitor and manage.",solution:"A compact control and monitoring concept for a small solar installation.",benefits:"More informed energy use and easier system monitoring."},
 {id:3,title:"AutoSort Robotics",category:"Automation",stage:"Idea",creator:"Daniel Musa",initials:"DM",role:"Automation Innovator",description:"A proposed automated sorting solution designed to support more consistent handling of recyclable materials.",icon:"⚙",art:"art-robot",funding:"Seeking technical collaborators",problem:"Manual sorting can be time-consuming and inconsistent.",solution:"An automation concept that uses sensors and control logic to classify items.",benefits:"Potentially faster sorting and improved process consistency."},
 {id:4,title:"SafeHome Circuit",category:"Smart Devices",stage:"Prototype",creator:"Tosin Bello",initials:"TB",role:"Electronics Designer",description:"A smart home electrical safety concept designed to help users monitor selected household circuit conditions.",icon:"⌂",art:"art-device",funding:"Seeking partners",problem:"Homeowners may not have an easy way to monitor selected electrical conditions.",solution:"A connected device concept that provides alerts and status information.",benefits:"More accessible monitoring and awareness of household electrical systems."},
 {id:5,title:"VoltTrack",category:"Electrical",stage:"Ready for Production",creator:"Chika Nwosu",initials:"CN",role:"Electrical Technologist",description:"A proposed equipment tracking and maintenance record platform for electrical workshops and facilities.",icon:"⌁",art:"",funding:"Open to business partnerships",problem:"Maintenance records and equipment information can be scattered across different places.",solution:"A centralised tracking concept for equipment records and maintenance reminders.",benefits:"Better organisation and maintenance planning."},
 {id:6,title:"AquaSense Controller",category:"Automation",stage:"Testing",creator:"Ibrahim Yusuf",initials:"IY",role:"Control Systems Designer",description:"A water-level monitoring and pump-control concept for small facilities and agricultural settings.",icon:"≈",art:"art-energy",funding:"Seeking investment discussion",problem:"Water storage and pumping systems may require frequent manual checks.",solution:"A sensor-based monitoring and control concept with status notifications.",benefits:"Convenient monitoring and more structured water management."}
];
const creators = [
 {name:"Emeka Okafor",initials:"EO",role:"Electrical Engineer",skill:"Energy Systems"},
 {name:"Amara James",initials:"AJ",role:"Renewable Energy Designer",skill:"Solar Technology"},
 {name:"Daniel Musa",initials:"DM",role:"Automation Innovator",skill:"Robotics & Control"}
];
const projectGrid=document.getElementById("projectGrid");
const creatorGrid=document.getElementById("creatorGrid");
const searchInput=document.getElementById("searchInput");
const categoryFilter=document.getElementById("categoryFilter");
const stageFilter=document.getElementById("stageFilter");
const accountModal=document.getElementById("accountModal");
const projectModal=document.getElementById("projectModal");
const toast=document.getElementById("toast");
let savedProjects=JSON.parse(localStorage.getItem("meetTechSaved")||"[]");

function showToast(message){
 toast.textContent=message;toast.classList.add("show");
 clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>toast.classList.remove("show"),2600);
}
function renderProjects(){
 const term=searchInput.value.trim().toLowerCase();
 const category=categoryFilter.value,stage=stageFilter.value;
 const filtered=projects.filter(p=>(category==="all"||p.category===category)&&(stage==="all"||p.stage===stage)&&[p.title,p.category,p.creator,p.description].join(" ").toLowerCase().includes(term));
 projectGrid.innerHTML=filtered.map(p=>`
 <article class="project-card">
  <div class="project-art ${p.art}"><span class="project-tag">${p.category}</span><button class="save-btn ${savedProjects.includes(p.id)?"saved":""}" data-save="${p.id}" aria-label="Save ${p.title}">${savedProjects.includes(p.id)?"♥":"♡"}</button><span class="art-symbol">${p.icon}</span></div>
  <div class="project-body"><div class="project-meta"><span>${p.category}</span><span class="stage">${p.stage}</span></div><h3>${p.title}</h3><p>${p.description}</p>
   <div class="creator-line"><span class="creator-avatar">${p.initials}</span><span>${p.creator}<small>${p.role}</small></span></div>
   <div class="card-actions"><button class="btn btn-outline" data-view="${p.id}">View project</button><button class="btn btn-primary" data-connect="${p.id}">Connect ↗</button></div>
  </div>
 </article>`).join("");
 if(!filtered.length)projectGrid.innerHTML='<p class="empty-state">No projects match your search. Try another keyword or filter.</p>';
}
function renderCreators(){
 creatorGrid.innerHTML=creators.map(c=>`<article class="creator-card"><div class="creator-photo">${c.initials}</div><div><h3>${c.name}</h3><p>${c.role}</p><span class="skill">${c.skill}</span></div></article>`).join("");
}
function openProject(id){
 const p=projects.find(item=>item.id===Number(id));if(!p)return;
 document.getElementById("projectDetails").innerHTML=`
 <span class="eyebrow">PROJECT OVERVIEW · ${p.category.toUpperCase()}</span>
 <div class="detail-art ${p.art}">${p.icon}</div><span class="detail-label">${p.stage.toUpperCase()}</span>
 <h2>${p.title}</h2><p>${p.description}</p>
 <p><b>Problem being addressed</b><br>${p.problem}</p>
 <p><b>How it works</b><br>${p.solution}</p>
 <p><b>Potential benefits</b><br>${p.benefits}</p>
 <p><b>Creator</b><br>${p.creator} — ${p.role}</p>
 <p><b>Collaboration status</b><br>${p.funding}</p>
 <button class="btn btn-primary btn-large" data-connect="${p.id}">Connect with creator ↗</button>`;
 projectModal.showModal();
}
function openAccount(mode="creator"){
 document.getElementById("accountType").value=mode;
 document.getElementById("modalTitle").textContent=mode==="company"?"Join as a company or investor.":"Create your creator profile.";
 accountModal.showModal();
}
projectGrid.addEventListener("click",e=>{
 const save=e.target.closest("[data-save]"),view=e.target.closest("[data-view]"),connect=e.target.closest("[data-connect]");
 if(save){const id=Number(save.dataset.save);savedProjects=savedProjects.includes(id)?savedProjects.filter(x=>x!==id):[...savedProjects,id];localStorage.setItem("meetTechSaved",JSON.stringify(savedProjects));renderProjects();showToast(savedProjects.includes(id)?"Project saved to your list.":"Project removed from saved list.");}
 if(view)openProject(view.dataset.view);
 if(connect){const p=projects.find(x=>x.id===Number(connect.dataset.connect));showToast(`Connection interest noted for ${p.title}. Sign in and messaging can be enabled with a backend.`);}
});
document.getElementById("projectDetails").addEventListener("click",e=>{
 const btn=e.target.closest("[data-connect]");if(btn){const p=projects.find(x=>x.id===Number(btn.dataset.connect));showToast(`Connection interest noted for ${p.title}.`);projectModal.close();}
});
[searchInput,categoryFilter,stageFilter].forEach(el=>el.addEventListener("input",renderProjects));
document.getElementById("joinBtn").addEventListener("click",()=>openAccount());
document.getElementById("joinBottomBtn").addEventListener("click",()=>openAccount());
document.getElementById("showcaseBtn").addEventListener("click",()=>openAccount("creator"));
document.getElementById("loginBtn").addEventListener("click",()=>showToast("Login requires a connected authentication service."));
document.getElementById("closeModal").addEventListener("click",()=>accountModal.close());
document.getElementById("closeProjectModal").addEventListener("click",()=>projectModal.close());
document.getElementById("accountForm").addEventListener("submit",e=>{
 e.preventDefault();
 const name=document.getElementById("accountName").value.trim();
 const type=document.getElementById("accountType").value;
 showToast(`Thanks, ${name}! Your ${type} demo profile is ready to be connected.`);
 accountModal.close();e.target.reset();
});
document.getElementById("loadMoreBtn").addEventListener("click",()=>showToast("You're viewing all sample projects currently available."));
document.getElementById("menuToggle").addEventListener("click",()=>document.getElementById("mainNav").classList.toggle("open"));
document.querySelectorAll(".nav-link").forEach(link=>link.addEventListener("click",()=>{
 document.querySelectorAll(".nav-link").forEach(item=>item.classList.remove("active"));link.classList.add("active");document.getElementById("mainNav").classList.remove("open");
}));
document.getElementById("year").textContent=new Date().getFullYear();
renderProjects();renderCreators();
